module.exports = {
	event: 'ready',
	once: true,
	run() {
		console.log('Bot is online!');
	},
};